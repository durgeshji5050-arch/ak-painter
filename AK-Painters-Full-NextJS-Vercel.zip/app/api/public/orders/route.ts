import {NextResponse} from 'next/server';
import {db} from '@/lib/db';

const keyFor=(service:string)=>`service_rate_${service.toLowerCase().replace(/[^a-z0-9]+/g,'_').replace(/^_|_$/g,'')}`;

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const name = String(body.name || '').trim();
    const phone = String(body.phone || '').trim();
    const email = String(body.email || '').trim();
    const serviceName = String(body.serviceName || '').trim();
    const notes = String(body.notes || '').trim();
    const quantity = Math.max(1, Number(body.quantity) || 1);
    if (!name || !phone || !serviceName) return NextResponse.json({error:'Name, mobile number and service are required.'},{status:400});

    const setting = await db.appSetting.findUnique({where:{key:keyFor(serviceName)}});
    const rate = Math.max(0, Number(setting?.value) || 0);
    const amount = rate * quantity;
    const client = await db.client.create({data:{name,phone,email:email||null,type:'OTHER',notes:notes||null}});
    const order = await db.order.create({data:{clientId:client.id,serviceName,quantity,amount,status:'NEW',notes:notes||null}});
    const wa = await db.appSetting.findUnique({where:{key:'admin_whatsapp'}});
    return NextResponse.json({ok:true,orderId:order.id,rate,amount,whatsapp:String(wa?.value||'').replace(/\D/g,'')});
  } catch {
    return NextResponse.json({error:'Unable to submit order right now.'},{status:500});
  }
}
