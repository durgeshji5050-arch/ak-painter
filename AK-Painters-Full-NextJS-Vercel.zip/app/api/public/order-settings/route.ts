import {NextResponse} from 'next/server';
import {db} from '@/lib/db';

export async function GET(){
  const rows=await db.appSetting.findMany();
  const rates:any={};
  for(const r of rows){ if(r.key.startsWith('service_rate_')) rates[r.key.replace('service_rate_','')]=Number(r.value)||0; }
  return NextResponse.json({rates});
}
