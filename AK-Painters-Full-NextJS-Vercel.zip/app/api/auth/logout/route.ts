import {NextResponse} from 'next/server';
import {cookies} from 'next/headers';

export async function POST(){
 const jar=await cookies();
 jar.set('ak_session','',{httpOnly:true,sameSite:'lax',secure:process.env.NODE_ENV==='production',path:'/',maxAge:0});
 return NextResponse.json({ok:true});
}
